import Vue from 'vue';
import HelloWorld from './HelloWorld.vue';

new Vue({
  el: '#app',
  render: h => h(HelloWorld)
})